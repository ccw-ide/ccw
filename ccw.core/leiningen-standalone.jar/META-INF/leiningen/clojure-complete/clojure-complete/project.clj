(defproject clojure-complete "0.2.3"
  :description "Standalone completion library adapted from swank-clojure"
  :dependencies [[org.clojure/clojure "1.3.0"]]
  :profiles {
    :1.2 {:dependencies [[org.clojure/clojure "1.2.0"]]}
    :1.3 {:dependencies [[org.clojure/clojure "1.3.0"]]}
    :1.4 {:dependencies [[org.clojure/clojure "1.4.0"]]}})
