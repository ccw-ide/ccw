(defproject net.cgrand/parsley "0.9.2"
  :description "a generator of total and truly incremental parsers"
  :url "http://github.com/cgrand/parsley/"
  :dependencies [[org.clojure/clojure "1.4.0"]
                 [net.cgrand/regex "1.1.0"]])

